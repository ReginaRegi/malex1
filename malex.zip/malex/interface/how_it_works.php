
<div class="how_it_works flex-container">
  
  <!--1st box-->
  <div class="how_it_works_1st">
    <p class="p_blue">how it works?</p>
    <h2>We Guarantee a Stable Work Process</h2>
  </div>

  <!--2nd box-->
  <div class="business_process1">
    <div class="backgr_number01">01</div>
    <div class="bus_proc_content01">
      <h4>Business Analyst</h4>
      <p class="">Lorem ipsum dolor sit, amet consectetur
        adipisicing elit. Fugiat, repellendus.</p>
    </div>
  </div>
<!--3rd box-->
<div class="business_process2">
  <div class="backgr_number02">02</div>
  <div class="bus_proc_content02">
    <h4>Business Planning</h4>
    <p class="p_white">Lorem ipsum dolor sit, amet consectetur
      adipisicing elit. Fugiat, repellendus.</p>
  </div>
</div>
<!--4th box-->
  <div class="business_process3">
    <div class="backgr_number03">03</div>
    <div class="bus_proc_content03">
      <h4>Business Growth</h4>
      <p class="p_white">Lorem ipsum dolor sit, amet consectetur
        adipisicing elit. Fugiat, repellendus.</p>
    </div>
  </div>
</div>
</div>
</section>