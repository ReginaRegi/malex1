
<body id="nav_white">
<div class="bckg_img_nav">

 <header class="site-header">
  <div class="container flex-container"> 

    <!--LOGO-->

    <div class="logo">
      <a href="../interface/index.php"><img src="../images/Logo.png" alt="malex logo"></a>
    </div>

    <!--NAVIGAION MENU-->

    <nav class="main-nav flex-container">
      <ul class="flex-container">
        <li><a href="../interface/strategic_planning.php" >Services</a></li>
        <li><a href="../interface/about_us.php" >About Us</a></li>
        <li><a href="#">Team</a></li>
        <li><a href="#" >Pricing</a></li>
        <li><a href="#" >Testimonials</a></li>
        <li><a href="../interface/news.php" >News</a></li>
        <li><a href="#" >Contacts</a></li>
      </ul>
    <div class="search"><a href="#"><i class="fas fa-search"></i></a></div>
    </nav>

    <!--Mobile nav menu-->
    <nav class="mob-main-nav flex-container">
      <ul class="flex-container" id="mMenu">
        <li><a href="../interface/strategic_planning.php">Services</a></li>
        <li><a href="../interface/about_us.php">About Us</a></li>
        <li><a href="#" >Team</a></li>
        <li><a href="#" >Pricing</a></li>
        <li><a href="#" >Testimonials</a></li>
        <li><a href="../interface/news.php" >News</a></li>
        <li><a href="#" >Contacts</a></li>
      </ul>

      <a href="javascript:void(0);" class="icon" onclick="myFunction()">
        <i class="fa fa-bars"></i>
      </a>
      
    </nav>

  </div>
 </header>