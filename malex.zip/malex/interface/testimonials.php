<section class="testimonials">
  <div class="container">
<div>
<p class="p_blue">TESTIMONIALS</p>
<h2>Our Happy Customers Reviews</h2>
</div>
<div class="qoute">
  <div class="backgr_quote_icon">
    <i class="fas fa-quote-left"></i></div>
  <p>But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give
  you a complete account.</p>
</div>
<div class="flex-container quote_person" >
  <p class="circle"></p>
  <p class="circle"> </p>
  <p class="circle"></p>
  <div>
    <p>Rosie Ford</p>
    <span>CEO at Company</span>
  </div>
</div>

</div>
</section>