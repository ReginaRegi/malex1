<section>
  <div class="container">
<div class="client_logo flex-container">
  <a href="#"><img src="../images/Logo_1.png" alt="Logo1"></a>
  <a href="#"><img src="../images/Logo_2.png" alt="Logo2"></a>
  <a href="#"><img src="../images/Logo_3.png" alt="Logo3"></a>
  <a href="#"><img src="../images/Logo_4.png" alt="Logo4"></a>
</div>
</div>
</section>