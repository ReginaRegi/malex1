 <form class="contact_form" id="contact" action="index.php" method="post">
        <h2>You can Write Us</h2>
        <p class="p_grey">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Natus maiores asperiores architecto ea? </p>

        <input type="text" name="name" placeholder="Name" required>
    
        <input type="email" name="email" placeholder="Email" required>
      <textarea name="message" rows="8" placeholder="Message" required></textarea>
       <button class="black_button form_btn" type="submit"name="submit" id="contact-submit">Send Message</button>
    </form>
  </div>
</section>