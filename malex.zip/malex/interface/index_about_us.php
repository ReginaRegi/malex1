<div class ="#"><a href="#">About Us</a></div>
  <div class="about_us_content flex-container">
      
    <!--Left Column-->
    <div class="about_us_col1">
      <div>        
        <h2>Keep Your Business Safe & Ensure High Availability</h2>
      </div>
      <div class="position1">
        <div class="flex-container">
          <img src="../images/Signature.png" alt="Tom Henders">
          <div>
            <h5>Tom Henders</h5>
            <span>CEO of Company</span>
          </div>
        </div>
      </div>
    </div>
<!--Right Column-->

    <div class="about_us_col2">
      <p class="p_grey">A business consulting agency is involved in the planning, implementation, and education of businesses. We work directly
      with business owners on developing a business plan, identifying marketing needs and developing the necessary skills for
      business ownership.</p>
      <p class="p_grey">Marketing consultant is an advisor who works with companies to create and implement marketing strategies.</p>
    </div>
  </div>
   <hr>
   <div class="benefits flex-container">
     <div><h6><i class="fas fa-check"></i>Constant Improvement</h6></div>
     <div><h6><i class="fas fa-check"></i>Commitment to Customer</h6></div>
     <div><h6><i class="fas fa-check"></i>Best quality You Can Get</h6></div>
     <div><h6><i class="fas fa-check"></i>30 days Money Back Warranty</h6></div>
   </div>