<footer>
  <div class="container flex-container">
  <div class="logo">
    <a href="#"><img src="../images/Logo.png" alt="malex logo"></a>
  </div>
  <div>
    <p class="p_grey">&copy; <?php echo date("Y");?> Business Consulting Agency Figma Template By Adveits</p>
  </div>
  <div class="social_links_footer">
    <ul class="flex-container">
      <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
      <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
      <li><a href="#"><i class="fab fa-instagram"></i></a></li>
    </ul>
  </div>
  </div>
</footer>
</body>
</html>